<?php
defined('MOODLE_INTERNAL') || die;

require_once($CFG->dirroot.'/lib/formslib.php');
 
class simplehtml_form extends moodleform {
    //Add elements to form
    public function definition() {
      //  global $CFG;
 
        $mform = $this->_form; // Don't forget the underscore! 
        
      
       

        $mform->addElement('select', 'group', 'select Group', $combobox_items,$FORUM_TYPES, $attributes);
        $mform->addElement('select', 'student', 'select student',array('s1'=>'student1','s2'=>'student2','s3'=>'student3'), $FORUM_TYPES, $attributes);
        $mform->addElement('submit', 'submitbutton','add this student to group');
        
    }
    //Custom validation should be added here
    function validation($data, $files) {
        return array();
    }
}
<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Main group self selection interface
 *
 * @package    mod_groupselect
 * @copyright  2018 HTW Chur Roger Barras
 * @copyright 2008-2011 Petr Skoda (http://skodak.org)
 * @copyright 2014 Tampere University of Technology, P. Pyykkönen (pirkka.pyykkonen ÄT tut.fi)
 * @license http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
require('../../config.php');
require_once('locallib.php');
require_once('select_form.php');
require('teacherfn_class.php');
require_once('create_form.php');

$PAGE->requires->jquery_plugin('groupselect-jeditable', 'mod_groupselect');

$id = optional_param( 'id', 0, PARAM_INT ); // Course Module ID, or
$g = optional_param( 'g', 0, PARAM_INT ); // Page instance ID
$select = optional_param( 'select', 0, PARAM_INT );
$unselect = optional_param( 'unselect', 0, PARAM_INT );
$confirm = optional_param( 'confirm', 0, PARAM_BOOL );
$create = optional_param( 'create', 0, PARAM_BOOL );
$password = optional_param( 'group_password', 0, PARAM_BOOL );
$export = optional_param( 'export', 0, PARAM_BOOL );
$assign = optional_param( 'assign', 0, PARAM_BOOL );
$unassign = optional_param( 'unassign', 0, PARAM_BOOL );
$groupid = optional_param( 'groupid', 0, PARAM_INT );
$newdescription = optional_param( 'newdescription', 0, PARAM_TEXT );

if ($g) {
    $groupselect = $DB->get_record( 'groupselect', array (
            'id' => $g
    ), '*', MUST_EXIST );
    $cm = get_coursemodule_from_instance( 'groupselect', $groupselect->id, $groupselect->course, false, MUST_EXIST );
} else {
    $cm = get_coursemodule_from_id( 'groupselect', $id, 0, false, MUST_EXIST );
    $groupselect = $DB->get_record( 'groupselect', array (
            'id' => $cm->instance
    ), '*', MUST_EXIST );
}

$course = $DB->get_record( 'course', array (
        'id' => $cm->course
), '*', MUST_EXIST );

require_login( $course, true, $cm );
$context = context_module::instance( $cm->id );

$PAGE->set_url( '/mod/groupselect/view.php', array (
        'id' => $cm->id
) );
$PAGE->add_body_class( 'mod_groupselect' );
$PAGE->set_title( $course->shortname . ': ' . $groupselect->name );
$PAGE->set_heading( $course->fullname );
$PAGE->set_activity_record( $groupselect );

$event = \mod_groupselect\event\course_module_viewed::create(array(
    'objectid' => $groupselect->id,
    'context' => $context,
));
$event->add_record_snapshot('course', $course);
$event->add_record_snapshot('groupselect', $groupselect);
$event->trigger();

$mygroups = groups_get_all_groups( $course->id, $USER->id, $groupselect->targetgrouping, 'g.*' );
$isopen = groupselect_is_open( $groupselect );
$groupmode = groups_get_activity_groupmode( $cm, $course );
$counts = groupselect_group_member_counts( $cm, $groupselect->targetgrouping );
$groups = groups_get_all_groups( $course->id, 0, $groupselect->targetgrouping );
$passwordgroups = groupselect_get_password_protected_groups( $groupselect );
$hidefullgroups = $groupselect->hidefullgroups;
$exporturl = '';


// Course specific supervision roles.
if (property_exists($groupselect, "supervisionrole") && $groupselect->supervisionrole > 0) {
    $assignrole = $groupselect->supervisionrole;
} else {
    $teacherrole = $DB->get_record( 'role', array (
        'shortname' => "teacher"
    ), '*', IGNORE_MISSING);
    // Assign non-editing teachers.
    if (empty($teacherrole)) {
        $assignrole = 4; // 4 is the moodle default value for the non-editing teachers.
    } else {
        $assignrole = $teacherrole->id;
    }
}


     





                    

   

// *** PAGE OUTPUT ***
echo $OUTPUT->header();


echo $OUTPUT->heading( format_string( $groupselect->name, true, array (
        'context' => $context
) ) );

if (trim( strip_tags( $groupselect->intro ) )) {
    echo $OUTPUT->box_start( 'mod_introbox', 'groupselectintro' );
    echo format_module_intro( 'groupselect', $groupselect, $cm->id );
    echo $OUTPUT->box_end();
}

// Too few members in my group-notification.
if ($groupselect->minmembers > 0 and ! empty( $mygroups )) {
    $mygroup = array_keys( $mygroups );
    foreach ($mygroup as $group) {
        $usercount = isset( $counts[$group] ) ? $counts[$group]->usercount : 0;
        if ($groupselect->minmembers > $usercount) {
            echo $OUTPUT->notification( get_string( 'minmembers_notification', 'mod_groupselect', $groupselect->minmembers ) );
            break;
        }
    }
}

// Too many members in my group-notification.
if ($groupselect->maxmembers > 0 and ! empty( $mygroups )) {
    $mygroup = array_keys( $mygroups );
    foreach ($mygroup as $group) {
        $usercount = isset( $counts[$group] ) ? $counts[$group]->usercount : 0;
        if ($groupselect->maxmembers < $usercount) {
            echo $OUTPUT->notification( get_string( 'maxmembers_notification', 'mod_groupselect', $groupselect->maxmembers ) );
            break;
        }
    }
}

// Activity opening/closing related notificatins.
if ($groupselect->timeavailable !== 0 and $groupselect->timeavailable > time()) {
    echo $OUTPUT->notification( get_string( 'timeavailable', 'mod_groupselect' ) . ' ' . strval( userdate( $groupselect->timeavailable ) ) );
}
if ($groupselect->timedue !== 0 and $groupselect->timedue > time()) {
    echo $OUTPUT->notification( get_string( 'timedue', 'mod_groupselect' ) . ' ' . strval( userdate( $groupselect->timedue ) ) );
}




      
echo $OUTPUT->heading( get_string( 'teacherAddStudent', 'mod_groupselect' ) );




$mform = new simplehtml_form(new moodle_url('teacher_Add_student_form_success.php'));
 
//Form processing and displaying is done here
if ($mform->is_cancelled()) {
    

    //Handle form cancel operation, if cancel button is present on form
} else if ($fromform = $mform->get_data()) {
    
} else {
   
   
$stud_query = $DB->get_records_sql('SELECT u.id,u.firstname, u.lastname FROM mdl_role_assignments ra, mdl_user u, mdl_course c, mdl_context cxt WHERE ra.userid = u.id AND ra.contextid = cxt.id AND cxt.contextlevel =50 AND cxt.instanceid = c.id AND c.id ='.$cm->course.' AND (roleid = 5) AND (SELECT count(*) from mdl_groups g,mdl_groups_members a WHERE a.userid=u.id and g.courseid='.$cm->course.' and g.id=a.groupid)=0');
        $students = array();
        foreach($stud_query as $s){
            $students += [$s->id=>$s->firstname.$s->lastname];
            
        }
    
  /*  
$groups_query = $DB->get_records_sql('SELECT id,name from mdl_groups gs WHERE (SELECT maxmembers from mdl_groupselect WHERE id=4)>(SELECT count(*) from mdl_groups_members WHERE groupid=gs.id)AND gs.courseid='.$cm->course.';')*/

$group_sql1 = 'select * from mdl_groups gs where 
((select count(userid) from mdl_groups_members where groupid = gs.id)<
(select maxmembers from mdl_groupselect where id ='.$groupselect->id.'))
and courseid = '.$cm->course.';' ;

$group_sql2 = 'select * from mdl_groups gs where id in 
(select groupid from mdl_groupings_groups where groupingid =(select targetgrouping from mdl_groupselect where id = '.$groupselect->id.'))
and
((select count(userid) from mdl_groups_members where groupid = gs.id)<
(select maxmembers from mdl_groupselect where id = '.$groupselect->id.'))
and courseid = '.$cm->course.'; ' ;


if ($groupselect->targetgrouping == 0 )
{

   
    $groups_query = $DB->get_records_sql($group_sql1);

}else {
   
    $groups_query = $DB->get_records_sql($group_sql2);

}



/*select * from mdl_groups gs where 
((select count(userid) from mdl_groups_members where groupid = gs.id)<
(select maxmembers from mdl_groupselect where id = 1))
and courseid = '.$cm->course.';'*/


    $groups = array();
        foreach($groups_query as $g){
            $groups += [$g->id=>$g->name];
            
        }
  echo html_writer::start_tag('form',array('method'=>'post','action'=>'teacher_Add_student_form_success.php','style'=>'width:200px'));
  echo html_writer::start_tag('label').'group</t>::'.html_writer::end_tag('label');
  echo html_writer::select($groups, 'group', '');
  echo html_writer::end_tag('br').html_writer::end_tag('br');
      echo html_writer::start_tag('label').'student</t>::'.html_writer::end_tag('label');
  echo html_writer::select($students, 'student', '');
  echo html_writer::end_tag('br').html_writer::end_tag('br');
  echo html_writer::start_tag('input',array('type'=>'submit','style'=>'width:200px'));
  echo html_writer::end_tag('form');

  
 
}
    

echo('<br>group select ='.$groupselect->id);
echo ('<br>course = '.$cm->course);
echo $OUTPUT->footer();

